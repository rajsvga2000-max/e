export type TransactionInput = {
  channel: string;
  amount: number;
  location: string;
  velocity: string;
  behaviour: string;
  history: string;
};

export type RiskResult = { score: number; factors: { name: string; points: number }[] };
export type Transaction = TransactionInput & RiskResult & { id: string; time: string; status: string; actions: string[] };

export const choices = {
  channel: ['ATM', 'UPI'],
  location: ['CHENNAI', 'MUMBAI', 'DELHI', 'BENGALURU', 'HYDERABAD', 'KOLKATA'],
  velocity: ['NORMAL', 'RAPID', 'VERY RAPID'],
  behaviour: ['NORMAL', 'LOCATION DEVIATION', 'AMOUNT DEVIATION', 'NEW DEVICE', 'MULTIPLE ANOMALIES'],
  history: ['NORMAL', 'SLIGHT DEVIATION', 'STRONG DEVIATION'],
};

export function calculateRisk(x: TransactionInput): RiskResult {
  let score = 0;
  const factors: RiskResult['factors'] = [];
  const add = (name: string, points: number) => { score += points; factors.push({ name, points }); };
  if (x.amount >= 100000) add('Very high amount', 24);
  else if (x.amount >= 80000) add('High amount', 15);
  else if (x.amount >= 50000) add('High amount', 11);
  else if (x.amount >= 25000) add('Amount deviation', 7);
  else if (x.amount >= 10000) add('Amount signal', 4);
  if (x.location !== 'CHENNAI') add('Location deviation', 16);
  if (x.velocity === 'VERY RAPID') add('Unusual velocity', 18);
  else if (x.velocity === 'RAPID') add('Unusual velocity', 11);
  if (x.behaviour === 'LOCATION DEVIATION') add('Behaviour change', 12);
  else if (x.behaviour === 'AMOUNT DEVIATION') add('Amount behaviour', 10);
  else if (x.behaviour === 'NEW DEVICE') add('Device anomaly', 16);
  else if (x.behaviour === 'MULTIPLE ANOMALIES') add('Multiple anomalies', 22);
  if (x.history === 'STRONG DEVIATION') add('History deviation', 17);
  else if (x.history === 'SLIGHT DEVIATION') add('History deviation', 8);
  if (x.channel === 'ATM' && x.velocity !== 'NORMAL') add('ATM velocity pattern', 9);
  if (x.channel === 'UPI' && x.behaviour === 'NEW DEVICE') add('UPI device signal', 6);
  return { score: Math.min(100, score), factors };
}

export function protocolFor(score: number, channel: string) {
  if (score < 25) return ['Monitor transaction'];
  if (score < 35) return ['Customer message'];
  if (score < 45) return ['Normal verification call'];
  if (score < 50) return ['Live call', 'Picture evidence'];
  if (score <= 75) return ['Customer message', 'Normal verification call', 'Video call'];
  return ['Customer message', 'Normal verification call', 'Video call', 'Authorized bank security escalation', channel === 'ATM' ? 'ATM footage / surveillance review' : 'Enhanced UPI transaction investigation', 'Identity-proof verification'];
}

export function riskLevel(score: number) {
  return score > 75 ? 'Critical' : score >= 50 ? 'High' : score >= 35 ? 'Elevated' : score >= 25 ? 'Suspicious' : 'Low';
}
export function riskTone(score: number) {
  return score > 75 ? 'danger' : score >= 35 ? 'warning' : 'safe';
}
export function statusFor(score: number) {
  return score > 75 ? 'Escalation' : score >= 50 ? 'Under review' : score >= 35 ? 'Verification' : 'Approved';
}
export function titleCase(value: string) { return value.toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase()); }
export function currency(amount: number) { return '₹' + amount.toLocaleString('en-IN', { maximumFractionDigits: 2 }); }

export const protocolTiers = [
  { range: '0–24%', title: 'Standard monitoring', description: 'Continue routine transaction monitoring.', tone: 'safe' },
  { range: '25–34%', title: 'Customer notification', description: 'Send a message to the account holder.', tone: 'safe' },
  { range: '35–44%', title: 'Identity verification', description: 'Request a normal verification call.', tone: 'warning' },
  { range: '45–49%', title: 'Enhanced verification', description: 'Live call and picture evidence recommended.', tone: 'warning' },
  { range: '50–75%', title: 'Security review', description: 'Customer message, verification, and video call.', tone: 'warning' },
  { range: '76–100%', title: 'Critical escalation', description: 'Bank security escalation and enhanced investigation.', tone: 'danger' },
];
