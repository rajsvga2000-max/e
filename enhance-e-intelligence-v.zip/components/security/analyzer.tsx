'use client';

import { useEffect, useRef, useState } from 'react';
import { ArrowRight, CircleHelp, Fingerprint, RotateCcw, ScanLine, ShieldCheck, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardAction, CardContent } from '@/components/ui/card';
import { Field, FieldGroup, FieldLabel } from '@/components/ui/field';
import { Input } from '@/components/ui/input';
import { NativeSelect, NativeSelectOption } from '@/components/ui/native-select';
import { Badge } from '@/components/ui/badge';
import { choices, riskLevel, riskTone, titleCase, type Transaction, type TransactionInput } from '@/lib/risk-engine';
import { cn } from '@/lib/utils';

type Props = { result: Transaction | null; onAnalyze: (input: TransactionInput) => void; onHelp: () => void; resetKey: number };
const emptyFields = { channel: '', amount: '', location: '', velocity: '', behaviour: '', history: '' };

export function Analyzer(props: Props) {
  return <AnalyzerForm key={props.resetKey} {...props} />;
}

function AnalyzerForm({ result, onAnalyze, onHelp }: Props) {
  const [fields, setFields] = useState(emptyFields);
  const [scanning, setScanning] = useState(false);
  const [message, setMessage] = useState('');
  const animation = useRef<Animation | null>(null);
  const formRef = useRef<HTMLFormElement>(null);
  const mounted = useRef(true);
  useEffect(() => {
    mounted.current = true;
    return () => { mounted.current = false; animation.current?.cancel(); };
  }, []);
  const update = (key: keyof typeof fields, value: string) => setFields((old) => ({ ...old, [key]: value }));
  const selectField = (key: keyof typeof choices, label: string, placeholder: string) => (
    <Field>
      <FieldLabel htmlFor={key}>{label}</FieldLabel>
      <NativeSelect id={key} name={key} value={fields[key]} onChange={(e) => update(key, e.target.value)} required disabled={scanning}>
        <NativeSelectOption value="" disabled>{placeholder}</NativeSelectOption>
        {choices[key].map((value) => <NativeSelectOption key={value} value={value}>{key === 'channel' ? value : titleCase(value)}</NativeSelectOption>)}
      </NativeSelect>
    </Field>
  );
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (scanning) return;
    const amount = Number(fields.amount);
    if (!Number.isFinite(amount) || amount <= 0) { setMessage('Enter a valid amount greater than zero.'); return; }
    setScanning(true);
    setMessage('');
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!reduced && formRef.current) {
      animation.current = formRef.current.animate([{ opacity: 1 }, { opacity: .65 }, { opacity: 1 }], { duration: 550 });
      try { await animation.current.finished; } catch { /* A canceled presentation animation must not prevent analysis. */ }
    }
    if (!mounted.current) return;
    onAnalyze({ ...fields, amount });
    setScanning(false);
    setMessage('Analysis complete. Recommended response updated.');
  }
  function loadExample() {
    setFields({ channel: 'UPI', amount: '85000', location: 'MUMBAI', velocity: 'RAPID', behaviour: 'NEW DEVICE', history: 'SLIGHT DEVIATION' });
    setMessage('Example loaded. Select Analyze transaction to calculate its risk.');
  }
  return (
    <Card className="analysis-card" id="analyzer">
      <CardHeader>
        <CardTitle><span className="section-icon"><ScanLine /></span>Transaction analyzer</CardTitle>
        <CardDescription>A clearer picture of every transaction.</CardDescription>
        <CardAction><Button variant="ghost" size="icon-sm" aria-label="About risk analysis" onClick={onHelp}><CircleHelp /></Button></CardAction>
      </CardHeader>
      <CardContent className="analyzer-content">
        <form ref={formRef} onSubmit={submit} className="transaction-form">
          <FieldGroup className="form-grid">
            {selectField('channel', 'Transaction channel', 'Select channel')}
            <Field>
              <FieldLabel htmlFor="amount">Amount (₹)</FieldLabel>
              <Input id="amount" name="amount" type="number" min="0.01" step="0.01" max="999999999999" placeholder="Enter amount" value={fields.amount} onChange={(e) => update('amount', e.target.value)} required disabled={scanning} />
            </Field>
            {selectField('location', 'Location', 'Select location')}
            {selectField('velocity', 'Transaction velocity', 'Select velocity')}
            {selectField('behaviour', 'Behaviour pattern', 'Select behaviour')}
            {selectField('history', 'Recent activity', 'Select activity')}
          </FieldGroup>
          <div className="form-actions">
            <Button type="submit" size="lg" disabled={scanning} className="analyze-button">{scanning ? <ScanLine className="spin" data-icon="inline-start" /> : <Fingerprint data-icon="inline-start" />}{scanning ? 'Analyzing transaction…' : 'Analyze transaction'}<ArrowRight data-icon="inline-end" /></Button>
            <Button type="button" variant="outline" size="icon-lg" disabled={scanning} aria-label="Clear transaction fields" onClick={() => { setFields(emptyFields); setMessage('Transaction fields cleared.'); }}><RotateCcw /></Button>
          </div>
          <div className="form-note"><span><ShieldCheck /> Rule-based risk engine</span><button type="button" onClick={loadExample} disabled={scanning}><Sparkles /> Try an example</button></div>
          <p className="form-status" role="status">{message}</p>
        </form>
        <div className={cn('risk-result', scanning && 'is-scanning')} aria-live="polite" aria-busy={scanning}>
          <div className="eyebrow">RISK ASSESSMENT <span className={cn('status-dot', result && 'is-active')} /></div>
          <div className={cn('risk-gauge', result && riskTone(result.score))}>
            <svg viewBox="0 0 180 180" aria-hidden="true"><circle className="gauge-track" cx="90" cy="90" r="75" /><circle className="gauge-value" cx="90" cy="90" r="75" pathLength="100" strokeDasharray={`${result?.score ?? 0} 100`} /></svg>
            <div className="gauge-inner"><span className="gauge-number">{scanning ? <ScanLine /> : result ? <>{result.score}<small>%</small></> : '—'}</span><span>{scanning ? 'SCANNING' : result ? 'RISK SCORE' : 'AWAITING INPUT'}</span></div>
          </div>
          {result ? <Badge variant={result.score > 75 ? 'destructive' : 'secondary'}>{riskLevel(result.score)} risk</Badge> : <span className="waiting-pill"><span className="status-dot" /> Ready to analyze</span>}
          <div className="risk-scale" aria-hidden="true"><i /><i /><i /><i /><i /><i /><i /><i /><i /><i /><i /><i /><i /><i /><i /><i /><i /><i /><i /><i /></div>
          <div className="scale-labels"><span>Low risk</span><span>Critical</span></div>
          <div className="risk-footnote">{result ? `${result.factors.length} risk signal${result.factors.length === 1 ? '' : 's'} detected` : 'Your risk assessment will appear here.'}</div>
        </div>
      </CardContent>
      {result && <div className="analysis-details reveal"><div><h3>Key risk factors</h3>{result.factors.length ? result.factors.map((factor) => <div className="factor-row" key={factor.name}><span>{factor.name}</span><b>+{factor.points}</b></div>) : <p>No abnormal signals detected.</p>}</div><div><h3>Recommended response</h3>{result.actions.map((action, index) => <div className="response-row" key={action}><span>{String(index + 1).padStart(2, '0')}</span>{action}</div>)}<p className="disclaimer">Recommendations only. No messages, calls, or bank actions are performed.</p></div></div>}
    </Card>
  );
}
