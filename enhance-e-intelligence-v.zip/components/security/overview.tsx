'use client';

import Image from 'next/image';
import { Activity, ArrowRight, ArrowUpRight, CircleAlert, Layers3, ShieldAlert, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardAction, CardContent, CardDescription } from '@/components/ui/card';
import type { Transaction } from '@/lib/risk-engine';

export function SecurityHero({ onAnalyze }: { onAnalyze: () => void }) {
  return <section className="security-hero reveal" aria-label="Security overview">
    <Image src="/images/security-core.png" alt="Sculptural glass security shield illuminated by lime circuit paths" fill priority sizes="(max-width: 760px) 100vw, 85vw" className="hero-artwork" />
    <div className="hero-shade" />
    <div className="hero-copy"><div className="hero-kicker"><span />INTELLIGENCE THAT PROTECTS</div><h2>See the risk.<br /><span>Stay ahead.</span></h2><p>Turn transaction signals into confident decisions.<br className="desktop-break" /> Your security command center, reimagined.</p><Button variant="outline" size="lg" onClick={onAnalyze}>Start an analysis<ArrowUpRight data-icon="inline-end" /></Button></div>
    <div className="hero-caption"><ShieldCheck /><span>ONE STEP AHEAD.<br /><strong>ALWAYS.</strong></span></div>
    <span className="hero-index">E–I / SECURITY INTELLIGENCE V5.0</span>
  </section>;
}

export function Metrics({ transactions }: { transactions: Transaction[] }) {
  const metrics = [
    { label: 'Transactions analyzed', value: transactions.length, icon: Layers3, note: 'In your current session', tone: 'neutral' },
    { label: 'High-risk transactions', value: transactions.filter((tx) => tx.score >= 50).length, icon: ShieldAlert, note: 'Risk score ≥ 50%', tone: 'warning' },
    { label: 'Critical alerts', value: transactions.filter((tx) => tx.score > 75).length, icon: CircleAlert, note: 'Requiring immediate review', tone: 'danger' },
  ];
  return <section className="metrics-grid reveal" aria-label="Session statistics">
    {metrics.map(({ label, value, icon: Icon, note, tone }) => <Card className="metric-card" key={label}><CardHeader><CardTitle>{label}</CardTitle><CardAction><Icon className={tone} /></CardAction></CardHeader><CardContent><div className="metric-value" key={value}>{value.toString().padStart(2, '0')}<span className="metric-unit">transactions</span></div><CardDescription><span className={`mini-dot ${tone}`} />{note}</CardDescription></CardContent></Card>)}
    <Card className="metric-card engine-metric"><CardHeader><CardTitle>Risk engine status</CardTitle><CardAction><Activity /></CardAction></CardHeader><CardContent><div className="metric-value engine-value">Active<span className="engine-indicator"><i /><i /><i /><i /><i /><i /><i /><i /></span></div><CardDescription><span className="mini-dot safe" />All analysis modules ready</CardDescription></CardContent></Card>
  </section>;
}
