'use client';

import { useEffect, useRef, useState } from 'react';
import { Activity, ArrowDownToLine, ArrowRight, Bell, CalendarDays, Check, ChevronDown, ChevronRight, CircleHelp, Command, FileText, Fingerprint, LayoutDashboard, Menu, Radio, RotateCcw, Settings2, Shield, ShieldAlert, ShieldCheck, Terminal, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardAction } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { Analyzer } from './analyzer';
import { SecurityHero, Metrics } from './overview';
import { RiskDistribution } from './risk-distribution';
import { LiveMonitor, Transactions, ProtocolPanel } from './session-panels';
import { calculateRisk, currency, protocolFor, riskLevel, statusFor, type Transaction, type TransactionInput } from '@/lib/risk-engine';
import { cn } from '@/lib/utils';

const navigation = [
  { label: 'Dashboard', icon: LayoutDashboard },
  { label: 'Risk analyzer', icon: Fingerprint },
  { label: 'Live monitor', icon: Radio },
  { label: 'Incident center', icon: ShieldAlert },
  { label: 'Protocol center', icon: ShieldCheck },
  { label: 'Reports & logs', icon: FileText },
];
type Panel = 'help' | 'settings' | 'notifications' | 'reset' | null;

export function SecurityDashboard() {
  const [active, setActive] = useState('Dashboard');
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [result, setResult] = useState<Transaction | null>(null);
  const [panel, setPanel] = useState<Panel>(null);
  const [selected, setSelected] = useState<Transaction | null>(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [resetKey, setResetKey] = useState(0);
  const [date, setDate] = useState('Current session');
  const [ready, setReady] = useState(false);
  const [notice, setNotice] = useState('');
  const noticeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const incidents = transactions.filter((tx) => tx.score >= 45);
  const critical = transactions.filter((tx) => tx.score > 75);
  useEffect(() => {
    setDate(new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }));
    setReady(true);
    return () => { if (noticeTimer.current) clearTimeout(noticeTimer.current); };
  }, []);
  function navigate(label: string) { setActive(label); setMobileOpen(false); window.scrollTo({ top: 0, behavior: 'instant' }); }
  function startAnalysis() {
    if (active !== 'Dashboard' && active !== 'Risk analyzer') { navigate('Risk analyzer'); return; }
    document.getElementById('analyzer')?.scrollIntoView({ behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth', block: 'center' });
    document.getElementById('channel')?.focus({ preventScroll: true });
  }
  function analyze(input: TransactionInput) {
    const risk = calculateRisk(input);
    const tx: Transaction = { ...input, ...risk, id: `TXN-${crypto.randomUUID().slice(0, 8).toUpperCase()}`, time: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' }), status: statusFor(risk.score), actions: protocolFor(risk.score, input.channel) };
    setTransactions((old) => [tx, ...old]);
    setResult(tx);
  }
  function exportReport() {
    const report = { application: 'E-Intelligence V5', exportedAt: new Date().toISOString(), mode: 'Session-only rule-based analysis', total: transactions.length, highRisk: transactions.filter((tx) => tx.score >= 50).length, critical: critical.length, transactions };
    const url = URL.createObjectURL(new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' }));
    const link = document.createElement('a'); link.href = url; link.download = `e-intelligence-report-${new Date().toISOString().slice(0, 10)}.json`; link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    setNotice('Session report exported.');
    if (noticeTimer.current) clearTimeout(noticeTimer.current);
    noticeTimer.current = setTimeout(() => setNotice(''), 3500);
  }
  function reset() { setTransactions([]); setResult(null); setSelected(null); setResetKey((key) => key + 1); setPanel(null); setNotice('Session reset. Ready for a fresh start.'); }
  return <div className="app-shell" data-ready={ready}>
    <a href="#main-content" className="skip-link">Skip to content</a>
    {mobileOpen && <button className="sidebar-backdrop" aria-label="Close navigation" onClick={() => setMobileOpen(false)} />}
    <aside className={cn('sidebar', mobileOpen && 'sidebar-open')}>
      <a href="#" onClick={(e) => { e.preventDefault(); navigate('Dashboard'); }} className="brand" aria-label="E-Intelligence dashboard"><span className="brand-symbol"><Shield fill="currentColor" /><Fingerprint /></span><span>E–INTELLIGENCE<small>SECURITY, REIMAGINED.</small></span></a>
      <div className="workspace-label"><span className="workspace-icon"><Command /></span><div>Security workspace<small>Personal session</small></div><span className="version-tag">V5</span></div>
      <p className="nav-label">WORKSPACE</p>
      <nav aria-label="Main navigation">{navigation.map(({ label, icon: Icon }) => <button key={label} onClick={() => navigate(label)} className={cn('nav-item', active === label && 'nav-active')} aria-current={active === label ? 'page' : undefined}><Icon /><span>{label}</span>{label === 'Incident center' && <span className="nav-counter">{incidents.length.toString().padStart(2, '0')}</span>}{active === label && <span className="nav-active-dot" />}</button>)}</nav>
      <div className="sidebar-bottom"><div className="sidebar-promo"><div className="promo-shield"><ShieldCheck /></div><strong>Built to stay ahead.</strong><p>Smarter analysis.<br />Safer transactions.</p><button onClick={() => setPanel('help')}>Explore your workspace<ArrowRight /></button><div className="promo-orbit" aria-hidden="true" /></div><button className="nav-item" onClick={() => setPanel('settings')}><Settings2 /><span>Settings</span></button><button className="nav-item" onClick={() => setPanel('help')}><CircleHelp /><span>Help & resources</span><ArrowRight /></button><Separator /><div className="analyst-profile"><div className="profile-avatar">SA<span /></div><div><strong>Security Analyst</strong><small>Local workspace</small></div><span className="profile-level">L2</span></div></div>
    </aside>
    <div className="main-shell">
      <header className="topbar"><div className="breadcrumb"><Button variant="ghost" size="icon" className="mobile-menu" aria-label="Open navigation" onClick={() => setMobileOpen(true)}><Menu /></Button><span className="breadcrumb-home"><LayoutDashboard /></span><span>Workspace</span><ChevronRight /><strong>{active}</strong></div><div className="topbar-right"><span className="system-status"><span className="status-dot is-active" />System operational</span><span className="topbar-divider" /><Button variant="ghost" size="icon" aria-label={`Notifications: ${incidents.length} incidents`} onClick={() => setPanel('notifications')}><Bell /></Button><button className="header-avatar" onClick={() => setPanel('settings')} aria-label="Workspace settings">SA</button></div></header>
      <main id="main-content" className="main-content">
        <div className="page-heading"><div><div className="page-eyebrow">YOUR SECURITY COMMAND CENTER</div><h1>{active === 'Dashboard' ? 'Overview' : active}</h1><p>{active === 'Dashboard' ? 'A smarter perspective on transaction security.' : 'Clarity in every signal. Confidence in every decision.'}</p></div><div className="heading-actions"><span className="session-date"><CalendarDays />{date}<span>·</span>This session</span><Button variant="outline" size="lg" onClick={exportReport}><ArrowDownToLine data-icon="inline-start" />Export report</Button></div></div>
        <div className="page-view" key={active}>
          {active === 'Dashboard' && <><SecurityHero onAnalyze={startAnalysis} /><Metrics transactions={transactions} /></>}
          {(active === 'Dashboard' || active === 'Risk analyzer') && <div className="main-grid"><Analyzer result={result} onAnalyze={analyze} onHelp={() => setPanel('help')} resetKey={resetKey} /><LiveMonitor transactions={transactions} onView={() => navigate('Live monitor')} /></div>}
          {active === 'Dashboard' && <div className="bottom-grid"><Transactions transactions={transactions} onAnalyze={startAnalysis} onSelect={setSelected} compact onViewAll={() => navigate('Live monitor')} /><ProtocolPanel onView={() => navigate('Protocol center')} /></div>}
          {(active === 'Live monitor' || active === 'Incident center') && <><Metrics transactions={transactions} /><Transactions transactions={transactions} onAnalyze={startAnalysis} onSelect={setSelected} incidents={active === 'Incident center'} /></>}
          {active === 'Live monitor' && transactions.length > 0 && <Card><CardHeader><CardTitle>Risk distribution</CardTitle><CardDescription>All transactions in your current session, grouped by the six response tiers.</CardDescription></CardHeader><CardContent><RiskDistribution transactions={transactions} /></CardContent></Card>}
          {active === 'Protocol center' && <ProtocolPanel expanded />}
          {active === 'Reports & logs' && <><Metrics transactions={transactions} /><Card><CardHeader><CardTitle><span className="section-icon"><Terminal /></span>Session activity log</CardTitle><CardDescription>A transparent record of this session. Export before closing the page.</CardDescription><CardAction><Button variant="outline" onClick={exportReport}><ArrowDownToLine data-icon="inline-start" />Export JSON</Button></CardAction></CardHeader><CardContent><div className="activity-log"><p><span>[SYSTEM]</span> E-Intelligence V5 session initialized.</p><p><span>[ENGINE]</span> Original percentage-driven response matrix loaded.</p>{[...transactions].reverse().map((tx) => <p key={tx.id}><time>{tx.time}</time> <span>[ANALYSIS]</span> {tx.id} · {tx.channel} · {currency(tx.amount)} → RISK {tx.score}% → {tx.status}</p>)}</div></CardContent></Card></>}
        </div>
        <footer className="page-footer"><span><ShieldCheck />E-INTELLIGENCE <b>V5.0</b><span className="footer-separator">/</span>Designed for a more secure tomorrow.</span><span><span className="status-dot is-active" />Session-only workspace<Button variant="ghost" size="sm" onClick={() => setPanel('reset')}><RotateCcw data-icon="inline-start" />Reset session</Button></span></footer>
      </main>
    </div>
    {notice && <div className="notice" role="status"><Check />{notice}<button aria-label="Dismiss notification" onClick={() => setNotice('')}><X /></button></div>}
    <Dialog open={panel !== null} onOpenChange={(open) => { if (!open) setPanel(null); }}><DialogContent className="workspace-dialog"><DialogHeader><DialogTitle>{panel === 'help' ? 'Intelligence, explained.' : panel === 'settings' ? 'Workspace settings' : panel === 'reset' ? 'Start a fresh session?' : 'Session notifications'}</DialogTitle><DialogDescription>{panel === 'help' ? 'Your original analyzer. A whole new perspective.' : panel === 'settings' ? 'A transparent look at how this workspace operates.' : panel === 'reset' ? 'This clears all current transactions, results, and incidents. Export a report first if you want to keep a copy.' : `${incidents.length} transaction${incidents.length === 1 ? '' : 's'} flagged for enhanced verification in this session.`}</DialogDescription></DialogHeader>
      {panel === 'help' && <div className="dialog-body"><div className="help-step"><span>01</span><div><strong>Enter a transaction</strong><p>Select the channel, amount, location, and behaviour. Or load a clearly marked example.</p></div></div><div className="help-step"><span>02</span><div><strong>Understand the signals</strong><p>The original rules score amount, location, velocity, device, and activity changes. Chennai is the baseline location.</p></div></div><div className="help-step"><span>03</span><div><strong>Review the next step</strong><p>Explore the recommended response protocol. This tool does not contact customers, access bank systems, or perform real fraud detection.</p></div></div><p className="disclaimer">This is a session-based demonstration, not a production financial security system. Data is cleared when the page reloads.</p></div>}
      {panel === 'settings' && <div className="dialog-body"><div className="settings-row"><span>Analysis engine</span><Badge variant="secondary">Rule-based · V5</Badge></div><div className="settings-row"><span>Baseline location</span><strong>Chennai, India</strong></div><div className="settings-row"><span>Currency</span><strong>INR (₹)</strong></div><div className="settings-row"><span>Storage</span><strong>Current session only</strong></div><div className="settings-row"><span>External services</span><strong>Not connected</strong></div><p className="disclaimer">Session data stays in this tab. Export your report before refreshing or closing it. Device reduced-motion preferences are respected.</p><a className="original-link" href="/original.html" target="_blank" rel="noreferrer">View the original dashboard<ArrowRight /></a></div>}
      {panel === 'notifications' && <div className="notification-list">{incidents.length ? incidents.map((tx) => <button key={tx.id} onClick={() => { setPanel(null); setSelected(tx); }}><ShieldAlert /><div><strong>{riskLevel(tx.score)} risk · {currency(tx.amount)}</strong><small>{tx.id} · {tx.time}</small></div><ChevronRight /></button>) : <div className="all-clear"><ShieldCheck /><h3>You&apos;re all caught up.</h3><p>Alerts will appear after a transaction scores 45% or higher.</p></div>}</div>}
      {panel === 'reset' && <DialogFooter><Button variant="outline" onClick={() => setPanel(null)}>Keep session</Button><Button variant="destructive" onClick={reset}>Reset session</Button></DialogFooter>}
    </DialogContent></Dialog>
    <Dialog open={selected !== null} onOpenChange={(open) => { if (!open) setSelected(null); }}><DialogContent className="workspace-dialog"><DialogHeader><DialogTitle>Transaction details</DialogTitle><DialogDescription>{selected?.id} · {selected?.time}</DialogDescription></DialogHeader>{selected && <div className="dialog-body"><div className="detail-summary"><strong>{currency(selected.amount)}</strong><Badge variant={selected.score > 75 ? 'destructive' : 'secondary'}>{selected.score}% · {riskLevel(selected.score)} risk</Badge></div><div className="settings-row"><span>Channel / location</span><strong>{selected.channel} / {selected.location}</strong></div><div className="settings-row"><span>Calculated status</span><strong>{selected.status}</strong></div><h3>Risk signals</h3>{selected.factors.length ? selected.factors.map((factor) => <div className="factor-row" key={factor.name}><span>{factor.name}</span><b>+{factor.points}</b></div>) : <p>No abnormal risk factors detected.</p>}<h3>Recommended response</h3>{selected.actions.map((action) => <div className="detail-action" key={action}><ChevronRight />{action}</div>)}<p className="disclaimer">Suggested steps only. No external actions have been performed.</p></div>}</DialogContent></Dialog>
  </div>;
}
