'use client';

import { Pie, PieChart } from 'recharts';
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from '@/components/ui/chart';
import type { Transaction } from '@/lib/risk-engine';

const ranges = [
  { key: 'low', label: '0–24%', min: 0, max: 25, color: 'var(--chart-1)' },
  { key: 'suspicious', label: '25–34%', min: 25, max: 35, color: 'var(--chart-2)' },
  { key: 'elevated', label: '35–44%', min: 35, max: 45, color: 'var(--chart-3)' },
  { key: 'verification', label: '45–49%', min: 45, max: 50, color: 'var(--chart-4)' },
  { key: 'high', label: '50–75%', min: 50, max: 76, color: 'var(--chart-5)' },
  { key: 'critical', label: '76–100%', min: 76, max: 101, color: 'var(--chart-6)' },
];
const config = Object.fromEntries(ranges.map((range) => [range.key, { label: range.label, color: range.color }])) satisfies ChartConfig;

export function RiskDistribution({ transactions }: { transactions: Transaction[] }) {
  const data = ranges.map((range) => ({ name: range.key, count: transactions.filter((tx) => tx.score >= range.min && tx.score < range.max).length, fill: `var(--color-${range.key})` }));
  return <section className="risk-distribution" aria-label="Session risk distribution"><h3>RISK DISTRIBUTION <span>{transactions.length} analyzed</span></h3><div className="distribution-content"><div className="distribution-ring"><ChartContainer config={config} className="size-[108px]" aria-label="Transactions grouped by risk score"><PieChart accessibilityLayer><Pie data={data} dataKey="count" nameKey="name" innerRadius={36} outerRadius={48} stroke="var(--card)" strokeWidth={3} isAnimationActive={false} /><ChartTooltip content={<ChartTooltipContent nameKey="name" hideLabel />} /></PieChart></ChartContainer><div className="distribution-total" aria-hidden="true"><strong>{transactions.length}</strong><span>TOTAL</span></div></div><dl className="distribution-legend">{ranges.map((range, index) => <div key={range.key}><dt><i style={{ background: range.color }} />{range.label}</dt><dd>{transactions.length ? Math.round(data[index].count / transactions.length * 100) : 0}%</dd></div>)}</dl></div></section>;
}
