'use client';

import { useState } from 'react';
import { Activity, ArrowDownLeft, ArrowRight, Check, ChevronRight, CircleDot, Radio, Search, ShieldCheck, SlidersHorizontal } from 'lucide-react';
import { Card, CardAction, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription } from '@/components/ui/empty';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { NativeSelect, NativeSelectOption } from '@/components/ui/native-select';
import { Input } from '@/components/ui/input';
import { currency, protocolTiers, riskLevel, riskTone, titleCase, type Transaction } from '@/lib/risk-engine';
import { cn } from '@/lib/utils';
import { RiskDistribution } from './risk-distribution';

export function LiveMonitor({ transactions, onView }: { transactions: Transaction[]; onView: () => void }) {
  return <Card className="monitor-card">
    <CardHeader><CardTitle><span className="section-icon"><Activity /></span>Live monitor</CardTitle><CardDescription>Your session, as it happens.</CardDescription><CardAction><span className="live-label"><span className="status-dot is-active" />LIVE</span></CardAction></CardHeader>
    <CardContent className="monitor-content">
      <div className="monitor-head"><span>TRANSACTION</span><span>RISK LEVEL</span></div>
      {transactions.length ? <div className="event-list">{transactions.slice(0, 4).map((tx) => <div className="event-row reveal" key={tx.id}><div className="transaction-symbol"><ArrowDownLeft /></div><div><strong>{currency(tx.amount)} <small>{tx.channel}</small></strong><span>{titleCase(tx.location)} · {tx.time}</span></div><span className={cn('risk-text', riskTone(tx.score))}><i />{riskLevel(tx.score)}</span></div>)}</div> : <Empty className="monitor-empty"><EmptyHeader><EmptyMedia><div className="radar-visual"><Radio /><span /></div></EmptyMedia><EmptyTitle>Listening for activity</EmptyTitle><EmptyDescription>Analyze your first transaction to<br />start your session feed.</EmptyDescription></EmptyHeader></Empty>}
      {transactions.length > 0 && <RiskDistribution transactions={transactions} />}
    </CardContent>
    <CardFooter className="monitor-footer"><span><span className="status-dot is-active" /> Session monitor ready</span><Button variant="ghost" size="icon-sm" aria-label="View all session transactions" onClick={onView}><ArrowRight /></Button></CardFooter>
  </Card>;
}

export function Transactions({ transactions, onAnalyze, onSelect, incidents = false, compact = false, onViewAll }: { transactions: Transaction[]; onAnalyze: () => void; onSelect: (transaction: Transaction) => void; incidents?: boolean; compact?: boolean; onViewAll?: () => void }) {
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('all');
  const filtered = transactions.filter((tx) => (!incidents || tx.score >= 45) && (filter === 'all' || (filter === 'high' ? tx.score >= 50 : tx.score < 50)) && `${tx.id} ${tx.channel} ${tx.location} ${tx.amount}`.toLowerCase().includes(query.toLowerCase()));
  const visible = compact ? filtered.slice(0, 4) : filtered;
  return <Card className="transactions-card">
    <CardHeader><CardTitle>{incidents ? 'Incident center' : 'Recent transactions'}<span className="count-label">{filtered.length.toString().padStart(2, '0')}</span></CardTitle><CardDescription>{incidents ? 'Transactions requiring enhanced verification.' : 'Every transaction. Every signal. In one place.'}</CardDescription><CardAction>{compact ? <Button variant="ghost" size="sm" onClick={onViewAll}>View all<ArrowRight data-icon="inline-end" /></Button> : <Button variant="outline" size="sm" onClick={onAnalyze}>New analysis<ArrowRight data-icon="inline-end" /></Button>}</CardAction></CardHeader>
    {!compact && <div className="table-tools"><div className="search-field"><Search /><Input aria-label="Search transactions" placeholder="Search ID, channel, amount, or location…" value={query} onChange={(event) => setQuery(event.target.value)} /></div><NativeSelect aria-label="Filter by risk" value={filter} onChange={(event) => setFilter(event.target.value)}><NativeSelectOption value="all">All risk levels</NativeSelectOption><NativeSelectOption value="high">High & critical</NativeSelectOption><NativeSelectOption value="low">Below high risk</NativeSelectOption></NativeSelect></div>}
    <CardContent className="transaction-table-wrap"><table className="transaction-table"><thead><tr><th>TRANSACTION</th><th>AMOUNT</th><th>LOCATION</th><th>RISK</th><th>STATUS</th><th><span className="sr-only">Details</span></th></tr></thead><tbody>{visible.map((tx) => <tr key={tx.id} className="reveal"><td><div className="table-identity"><span className="transaction-symbol"><ArrowDownLeft /></span><div><strong>{tx.channel} payment</strong><small>{tx.id} · {tx.time}</small></div></div></td><td>{currency(tx.amount)}</td><td>{titleCase(tx.location)}</td><td><span className={cn('risk-text', riskTone(tx.score))}><i />{tx.score}%</span></td><td><Badge variant={tx.score > 75 ? 'destructive' : 'outline'}>{tx.status}</Badge></td><td><Button variant="ghost" size="icon-sm" aria-label={`View ${tx.id}`} onClick={() => onSelect(tx)}><ChevronRight /></Button></td></tr>)}</tbody></table>
    {!visible.length && <Empty className="table-empty"><EmptyHeader><EmptyMedia variant="icon">{incidents ? <ShieldCheck /> : <SlidersHorizontal />}</EmptyMedia><EmptyTitle>{query || filter !== 'all' ? 'No matching transactions' : incidents ? 'No incidents to review' : 'A clean slate. A secure start.'}</EmptyTitle><EmptyDescription>{query || filter !== 'all' ? 'Try a different search or risk level.' : incidents ? 'Transactions scoring 45% or higher will appear here.' : 'Your analyzed transactions will appear here.'}</EmptyDescription></EmptyHeader>{!incidents && !query && filter === 'all' && <Button variant="link" size="sm" onClick={onAnalyze}>Analyze a transaction<ArrowRight data-icon="inline-end" /></Button>}</Empty>}
    </CardContent>
  </Card>;
}

export function ProtocolPanel({ expanded = false, onView }: { expanded?: boolean; onView?: () => void }) {
  const tiers = expanded ? protocolTiers : [protocolTiers[0], protocolTiers[2], protocolTiers[5]];
  return <Card className="protocol-card"><CardHeader><CardTitle><span className="section-icon"><ShieldCheck /></span>Response protocols</CardTitle><CardDescription>Prepared for every risk level.</CardDescription><CardAction><Badge variant="outline">6 tiers</Badge></CardAction></CardHeader><CardContent><div className="protocol-list">{tiers.map((tier) => <div className="protocol-row" key={tier.range}><span className={cn('protocol-symbol', tier.tone)}>{tier.tone === 'safe' ? <Check /> : <CircleDot />}</span><div><strong>{tier.title}</strong><p>{expanded ? tier.description : `Risk score ${tier.range}`}</p></div><span className={cn('protocol-range', tier.tone)}>{tier.range}</span></div>)}</div>{expanded && <p className="disclaimer">The original percentage-based response matrix is preserved. These are recommendations, not automated banking actions. Chennai is the baseline location.</p>}</CardContent>{!expanded && <CardFooter><Button variant="ghost" className="w-full justify-between" onClick={onView}>Explore all protocols<ArrowRight data-icon="inline-end" /></Button></CardFooter>}</Card>;
}
